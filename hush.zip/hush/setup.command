#!/bin/bash
# Hush one-time setup. Double-click me (right-click > Open the first time).
set -e
cd "$(dirname "$0")"

echo ""
echo "  Hush setup starting..."
echo ""

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found. macOS will now offer to install its"
  echo "developer tools (this includes Python). Click Install in the popup,"
  echo "wait for it to finish, then double-click this file again."
  xcode-select --install || true
  exit 1
fi

echo "1/3 Creating an isolated Python environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip --quiet

echo "2/3 Installing libraries (audio, speech model, menu bar, hotkeys)..."
pip install -r requirements.txt --quiet

echo "3/3 Downloading the speech model (~1.6 GB, one time only)."
echo "    This is the part that makes Hush fully private: the model lives"
echo "    on your Mac, so your voice never goes to any server."
python3 - <<'PY'
import numpy as np
import mlx_whisper
mlx_whisper.transcribe(
    np.zeros(16000, dtype="float32"),
    path_or_hf_repo="mlx-community/whisper-large-v3-turbo",
)
print("    Model downloaded and verified.")
PY

chmod +x "Start Hush.command" 2>/dev/null || true

echo ""
echo "  Setup complete."
echo "  Next: open SETUP_GUIDE.md for the 2-minute permissions step,"
echo "  then double-click 'Start Hush.command' to launch."
echo ""
