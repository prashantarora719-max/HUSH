"""Hush - private, on-device voice dictation for macOS.

Hold the hotkey anywhere, speak, release. Clean text appears at your cursor.
Nothing ever leaves your Mac.
"""

import subprocess
import threading

import numpy as np
import rumps
from pynput import keyboard

import cleanup
import config
import injector
import recorder
import transcriber

ICON_IDLE = "\U0001F399"   # studio microphone
ICON_REC = "\U0001F534"    # red circle
ICON_BUSY = "\u2728"       # sparkles

HOTKEYS = {
    "alt_r": (keyboard.Key.alt_r, "right Option (\u2325)"),
    "cmd_r": (keyboard.Key.cmd_r, "right Command (\u2318)"),
    "ctrl_r": (keyboard.Key.ctrl_r, "right Control (\u2303)"),
}

MODE_LABELS = {
    "off": "Cleanup: Off (raw transcript)",
    "light": "Cleanup: Light (recommended)",
    "full": "Cleanup: Full (AI rewrite, needs Ollama)",
}

# Whisper sometimes hallucinates these on silence/very short audio
_SILENCE_JUNK = {"you", "thank you.", "thanks.", "thank you", "."}


class Hush(rumps.App):
    def __init__(self):
        super().__init__("Hush", title=ICON_IDLE, quit_button="Quit Hush")
        self.cfg = config.load()
        self.rec = recorder.Recorder()
        self.recording = False
        self.busy = True  # blocked until the model warm-up finishes

        hotkey_id = self.cfg.get("hotkey", "alt_r")
        if hotkey_id not in HOTKEYS:
            hotkey_id = "alt_r"
        self.hotkey, hotkey_label = HOTKEYS[hotkey_id]

        # --- Menu ---
        self.mode_items = {}
        for mode, label in MODE_LABELS.items():
            item = rumps.MenuItem(label, callback=self._make_mode_setter(mode))
            self.mode_items[mode] = item
        self.sound_item = rumps.MenuItem("Sounds", callback=self.toggle_sounds)
        self.sound_item.state = 1 if self.cfg.get("sounds", True) else 0

        self.menu = [
            rumps.MenuItem(f"Hold {hotkey_label} to dictate"),
            None,
            self.mode_items["off"],
            self.mode_items["light"],
            self.mode_items["full"],
            None,
            self.sound_item,
            rumps.MenuItem("Edit dictionary & settings...", callback=self.edit_config),
            None,
        ]
        self._sync_mode_checks()

        # --- Global hotkey listener (runs on its own thread) ---
        self.listener = keyboard.Listener(
            on_press=self.on_press, on_release=self.on_release
        )
        self.listener.start()

        # --- Warm up the model in the background so dictation #1 is fast ---
        self.title = ICON_BUSY
        threading.Thread(target=self._warmup, daemon=True).start()

    # ---------- menu callbacks ----------

    def _make_mode_setter(self, mode):
        def setter(_):
            if mode == "full" and not cleanup.ollama_available():
                rumps.notification(
                    "Hush", "Ollama not detected",
                    "Full mode needs the Ollama app running. "
                    "Falling back to Light until it is. See SETUP_GUIDE.md.",
                )
            self.cfg["cleanup_mode"] = mode
            config.save(self.cfg)
            self._sync_mode_checks()
        return setter

    def _sync_mode_checks(self):
        current = self.cfg.get("cleanup_mode", "light")
        for mode, item in self.mode_items.items():
            item.state = 1 if mode == current else 0

    def toggle_sounds(self, item):
        self.cfg["sounds"] = not self.cfg.get("sounds", True)
        item.state = 1 if self.cfg["sounds"] else 0
        config.save(self.cfg)

    def edit_config(self, _):
        subprocess.run(["open", "-e", config.CONFIG_PATH])
        rumps.notification(
            "Hush", "Editing settings",
            "Save the file, then quit and relaunch Hush to apply.",
        )

    # ---------- hotkey handling ----------

    def on_press(self, key):
        if key == self.hotkey and not self.recording and not self.busy:
            self.recording = True
            self.title = ICON_REC
            self._play("Pop")
            try:
                self.rec.start()
            except Exception as e:
                self.recording = False
                self.title = ICON_IDLE
                rumps.notification("Hush", "Microphone error", str(e))

    def on_release(self, key):
        if key == self.hotkey and self.recording:
            self.recording = False
            self.title = ICON_BUSY
            threading.Thread(target=self._process, daemon=True).start()

    # ---------- the pipeline ----------

    def _process(self):
        self.busy = True
        try:
            audio = self.rec.stop()

            # Ignore accidental taps shorter than ~0.4 seconds
            if len(audio) < 0.4 * recorder.SAMPLE_RATE:
                return

            text = transcriber.transcribe(
                audio,
                model=self.cfg["model"],
                dictionary=self.cfg.get("dictionary", []),
                language=self.cfg.get("language"),
            )

            if not text or text.strip().lower() in _SILENCE_JUNK:
                return

            mode = self.cfg.get("cleanup_mode", "light")
            if mode == "light":
                text = cleanup.light(text)
            elif mode == "full":
                try:
                    text = cleanup.full(text, self.cfg.get("ollama_model", "llama3.2:3b"))
                except Exception:
                    text = cleanup.light(text)  # graceful fallback

            injector.paste_text(text)
            self._play("Glass")
        except Exception as e:
            rumps.notification("Hush", "Something went wrong", str(e))
        finally:
            self.busy = False
            self.title = ICON_IDLE

    def _warmup(self):
        try:
            transcriber.transcribe(
                np.zeros(int(0.5 * recorder.SAMPLE_RATE), dtype="float32"),
                model=self.cfg["model"],
            )
        except Exception as e:
            rumps.notification("Hush", "Model warm-up issue", str(e))
        finally:
            self.busy = False
            self.title = ICON_IDLE
            rumps.notification(
                "Hush", "Ready",
                "Hold your hotkey in any app and start speaking.",
            )

    def _play(self, name):
        if self.cfg.get("sounds", True):
            subprocess.Popen(
                ["afplay", f"/System/Library/Sounds/{name}.aiff"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )


if __name__ == "__main__":
    Hush().run()
