"""On-device speech-to-text using mlx-whisper on Apple Silicon.

The model is downloaded once, then cached on disk. mlx-whisper also keeps the
loaded model in memory between calls, so only the first transcription after
launch pays the loading cost.
"""

import mlx_whisper


def transcribe(audio, model, dictionary=None, language=None):
    # Whisper's initial_prompt biases it toward spelling these words correctly.
    # This is how the personal dictionary works.
    prompt = None
    if dictionary:
        prompt = "Vocabulary: " + ", ".join(dictionary)

    result = mlx_whisper.transcribe(
        audio,
        path_or_hf_repo=model,
        initial_prompt=prompt,
        language=language,
    )
    return result["text"].strip()
