"""The cleanup layer. This is Hush's answer to Wispr Flow's over-editing
problem: the user chooses how aggressive the cleanup is.

  off   -> raw transcript, exactly what Whisper heard
  light -> conservative rules: remove filler words, tidy spacing/punctuation
  full  -> a small local LLM (via Ollama) rewrites for clarity, applying
           self-corrections. Falls back to light if Ollama is unavailable.
"""

import json
import re
import urllib.request

# Conservative filler list. Deliberately does NOT include words like "like"
# or "so" which often carry real meaning.
_FILLERS = re.compile(r"\b(um+|uh+|erm+|hmm+|uhh+|umm+)\b[,.]?\s*", re.IGNORECASE)


def light(text):
    t = _FILLERS.sub("", text)
    t = re.sub(r"\s{2,}", " ", t).strip()          # collapse double spaces
    t = re.sub(r"\s+([,.!?;:])", r"\1", t)          # no space before punctuation
    t = re.sub(r"([,.!?;:])(\w)", r"\1 \2", t)      # space after punctuation
    if t and t[0].islower():
        t = t[0].upper() + t[1:]
    if t and t[-1] not in ".!?\u2026":
        t += "."
    return t


_PROMPT = (
    "You are a dictation cleanup engine. Rewrite the transcript below into "
    "clean, natural written text.\n"
    "Rules:\n"
    "- Keep the speaker's meaning, tone and language exactly. If they mix "
    "Hindi and English, keep the mix.\n"
    "- Remove filler words and false starts.\n"
    "- Apply self-corrections: if they say 'Tuesday, no wait, Friday', "
    "output 'Friday'.\n"
    "- Fix grammar lightly. Never add new information. Never answer "
    "questions that appear in the transcript.\n"
    "- Output ONLY the cleaned text, nothing else.\n\n"
    "Transcript: {text}"
)


def full(text, ollama_model="llama3.2:3b", timeout=40):
    """AI rewrite via the local Ollama server. Raises on any failure so the
    caller can fall back to light()."""
    body = json.dumps({
        "model": ollama_model,
        "prompt": _PROMPT.format(text=text),
        "stream": False,
        "options": {"temperature": 0.2},
    }).encode()
    req = urllib.request.Request(
        "http://localhost:11434/api/generate",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        cleaned = json.loads(resp.read())["response"].strip()
    # Strip quotes some models like to wrap output in
    if len(cleaned) > 1 and cleaned[0] in "\"'\u201c" and cleaned[-1] in "\"'\u201d":
        cleaned = cleaned[1:-1].strip()
    return cleaned if cleaned else text


def ollama_available():
    try:
        with urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2):
            return True
    except Exception:
        return False
