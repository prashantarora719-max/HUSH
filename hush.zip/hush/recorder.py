"""Microphone capture. Starts when the hotkey is pressed, stops on release."""

import numpy as np
import sounddevice as sd

SAMPLE_RATE = 16000  # what Whisper models expect


class Recorder:
    def __init__(self):
        self._frames = []
        self._stream = None

    def start(self):
        self._frames = []
        self._stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            callback=self._on_audio,
        )
        self._stream.start()

    def _on_audio(self, indata, frames, time_info, status):
        # Called by the audio system many times per second with small chunks
        self._frames.append(indata.copy())

    def stop(self):
        """Stop recording and return everything captured as one flat array."""
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        if not self._frames:
            return np.zeros(0, dtype="float32")
        audio = np.concatenate(self._frames).flatten()
        self._frames = []
        return audio
