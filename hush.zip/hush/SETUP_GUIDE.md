# Hush Setup Guide

Private, on-device voice dictation for your Mac. Hold a key, speak, release, and clean text appears wherever your cursor is. Your voice never leaves your machine.

Total setup time: about 15 minutes, most of it a one-time model download.

## Step 1: Put the folder in place

Unzip `hush.zip` and move the `hush` folder somewhere permanent, like your home folder or Documents. Don't run it from Downloads and then move it later.

## Step 2: Run setup (one time)

Right-click `setup.command` and choose **Open**, then click **Open** again in the security popup. (This right-click dance is only needed the first time; macOS is cautious about files from the internet.)

A Terminal window opens and does three things: creates an isolated Python environment, installs the libraries, and downloads the 1.6 GB speech model. On a decent connection this takes 5-10 minutes. When it says "Setup complete", close the window.

If it complains that Python is missing, macOS will pop up an installer for its developer tools. Click Install, wait, then run `setup.command` again.

## Step 3: Grant the three permissions (the important part)

Hush needs the same permissions every dictation app needs. Because you launch it through Terminal, you grant them to **Terminal**.

Open **System Settings > Privacy & Security**, then in each of these three sections, find **Terminal** and switch it on (use the + button to add it from the Applications > Utilities folder if it isn't listed):

1. **Microphone** — so Hush can hear you
2. **Input Monitoring** — so the hotkey works in any app
3. **Accessibility** — so Hush can paste text at your cursor

macOS may also prompt you for these the first time you use Hush. Approve them, then quit and relaunch the app.

## Step 4: Launch

Double-click `Start Hush.command` (right-click > Open the first time). A microphone icon appears in your menu bar, shows sparkles while the model warms up (10-20 seconds), then you'll get a "Ready" notification.

**To dictate:** click into any text field (WhatsApp Web, Gmail, Notes, anywhere), hold the **right Option (⌥)** key, speak, release. Your words appear at the cursor in about 1-2 seconds.

## The cleanup modes (menu bar icon > Cleanup)

- **Off** — exactly what you said, raw
- **Light** (default) — removes um/uh, tidies punctuation, never rewrites you
- **Full** — a local AI model rewrites for clarity and applies self-corrections ("Tuesday, no wait, Friday" becomes "Friday"). Needs Ollama, below.

## Optional: enable Full mode with Ollama

1. Download Ollama from https://ollama.com and install it (it's a normal Mac app)
2. Open Terminal and run: `ollama pull llama3.2:3b` (a ~2 GB one-time download)
3. Keep Ollama running in the background, and switch Hush to Cleanup: Full

Like everything else in Hush, this AI runs entirely on your Mac.

## Personal dictionary

Menu bar icon > **Edit dictionary & settings**. Add names, company names, and jargon to the `dictionary` list so they're spelled correctly (e.g. "ChainSys", "OnMobile", "Metayb"). Save the file, quit and relaunch Hush.

## Troubleshooting

- **Hotkey does nothing** → Input Monitoring permission is missing for Terminal. Grant it, quit Hush (menu bar icon > Quit), relaunch.
- **Text is transcribed but never appears** → Accessibility permission is missing. Grant it and relaunch.
- **"Microphone error"** → Microphone permission is missing, or another app has locked the mic.
- **First dictation is slow** → Normal; the model is warming up. Wait for the "Ready" notification.
- **Hindi comes out in Devanagari script** → That's correct auto-detection. If you want everything forced to English, set `"language": "en"` in settings (mixed Hinglish works best on auto).
- **"cannot be opened because it is from an unidentified developer"** → Right-click the file and choose Open instead of double-clicking.
- **Anything else** → Copy whatever the Terminal window says and paste it to Claude. That window is our debug log.

## What makes this different from Wispr Flow

Everything runs on your Mac: no cloud, no account, no subscription, no screenshots of your screen, works on a plane. And you control how much the AI edits you, instead of it silently rewriting your words.
