"""Text injection. Puts the cleaned text on the clipboard, simulates Cmd+V in
whatever app has focus, then restores your original clipboard.

This is the same technique most dictation tools use because it is far more
reliable than simulating individual keystrokes, especially for Hindi or any
non-ASCII text.
"""

import subprocess
import time


def _get_clipboard():
    return subprocess.run(["pbpaste"], capture_output=True).stdout


def _set_clipboard(data):
    subprocess.run(["pbcopy"], input=data)


def paste_text(text):
    original = _get_clipboard()
    _set_clipboard(text.encode("utf-8"))
    time.sleep(0.1)  # let the clipboard settle
    subprocess.run([
        "osascript", "-e",
        'tell application "System Events" to keystroke "v" using command down',
    ])
    time.sleep(0.3)  # let the paste land before restoring
    _set_clipboard(original)
