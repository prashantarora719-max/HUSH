#!/bin/bash
# Launches Hush. Keep this Terminal window open while using it -
# it shows logs, which helps if we ever need to debug together.
cd "$(dirname "$0")"
source venv/bin/activate
echo ""
echo "  Hush is starting. Look for the microphone icon in your menu bar"
echo "  (top-right of the screen). Leave this window open."
echo ""
python3 app.py
