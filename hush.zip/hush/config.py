"""Hush settings. Stored as a simple JSON file you can edit in TextEdit."""

import json
import os

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

DEFAULTS = {
    # Which key you hold to dictate. Options: "alt_r" (right Option),
    # "cmd_r" (right Command), "ctrl_r" (right Control)
    "hotkey": "alt_r",

    # "off" = raw transcript, "light" = remove fillers + tidy punctuation,
    # "full" = AI rewrite using a local Ollama model (falls back to light if
    # Ollama is not running)
    "cleanup_mode": "light",

    # The local speech model. large-v3-turbo is the best quality/speed balance
    # on Apple Silicon. Smaller option: "mlx-community/whisper-small-mlx"
    "model": "mlx-community/whisper-large-v3-turbo",

    # null = auto-detect (recommended, handles Hinglish). Set to "en" to force
    # English output.
    "language": None,

    # Words Whisper should spell correctly: names, companies, jargon.
    # Add your own here.
    "dictionary": [
        "LinkedIn",
        "Sales Navigator",
        "Prashant",
        "Hush",
    ],

    # The Ollama model used for Full cleanup mode
    "ollama_model": "llama3.2:3b",

    # Subtle start/finish sounds
    "sounds": True,
}


def load():
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                cfg.update(json.load(f))
        except (json.JSONDecodeError, OSError):
            pass  # broken file: fall back to defaults, rewrite below
    save(cfg)
    return cfg


def save(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
